/*

#include <stdio.h>
#include <string.h>

int main(){

  char palavra1[50];
  char palavra2[50];
  int contP1 = 0, contP2 = 0, contTam = 0, contTam2 = 0, tam1, tam2;
  int igualTam = 0, igualLetra = 0;

  scanf("%s", palavra1);
  scanf("%s", palavra2);

  tam1 = strlen(palavra1);
  tam2 = strlen(palavra2);

  for(int i = 0; i < tam1; i++){
      contTam++;
  }
  for(int j = 0; j < tam2; j++){
      contTam2++;
  }

  if(contTam == contTam2){
      igualTam = 1;
  }else{
      igualTam = 0;
  }

  
  for(int i = 0; i < tam1; i++){

    contP1 = 0;
    contP2 = 0;

    for(int j = 0; j < tam1; j++){
        if(palavra1[i] == palavra1[j]){
            ++contP1;
        }
    }

    for(int k = 0; k < tam2; k++){
      if(palavra1[i] == palavra2[k]){
        ++contP2;
      }
    }

    if(contP1 != contP2){
      igualLetra = 1;
      //printf("Nao sao anagramas\n");
    }else{
      igualLetra = 0;
      //printf("Sao anagramas\n");
    }
  }

  printf("Os tamanhos sao: %d %d %d\n", contTam, contTam2, igualTam);
  printf("Palavras iguais: %d\n", igualLetra);

  if(igualTam == 1 && igualLetra == 1){
      printf("sim\n");
  }else{
      printf("nao\n");
  }
}
*/




/*
#include <stdio.h>
#include <string.h>

int main(){

  char palavra1[50];
  char palavra2[50];
  int contP1 = 0, contP2 = 0, contTam = 0, contTam2 = 0, tam1, tam2;
  int igualTam = 0, igualLetra = 0;

  scanf("%s", palavra1);
  scanf("%s", palavra2);

  tam1 = strlen(palavra1);
  tam2 = strlen(palavra2);

  for(int i = 0; i < tam1; i++){
      contTam++;
  }
  for(int j = 0; j < tam2; j++){
      contTam2++;
  }

  if(contTam == contTam2){
      igualTam = 1;
  }else{
      igualTam = 0;
  }

  
  for(int i = 0; i < tam1; i++){

    contP1 += palavra1[i];
  }

  for(int i = 0; i < tam2; i++){

    contP2 += palavra2[i];
  }

  contP1 == contP2 ? printf("sim\n") : printf("nao\n");

}




*/

  /*
  printf("Os tamanhos sao: %d %d %d\n", contTam, contTam2, igualTam);
  printf("Palavras iguais: %d\n", igualLetra);

  if(igualTam == 1 && igualLetra == 1){
      printf("sim\n");
  }else{
      printf("nao\n");
  }
  */