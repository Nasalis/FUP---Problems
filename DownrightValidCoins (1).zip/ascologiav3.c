/*
#include <stdio.h>
#include <string.h>

int main(){

  int soma = 0, resul = 0;
  char letra[22];
  scanf("%s", letra);
  int tam = strlen(letra);

  for(int i = 0; i < tam; i++){

    soma += letra[i];
  }

  printf("%d\n", soma%50);

  int menor_valor = 50;
  char caractere;

  for(char j = 'a'; j < 'z'; j++){
    if((soma + j)%50 < menor_valor){
      menor_valor = (soma + j)%50;
      caractere = j;
    }
  }
  if(*letra == caractere){
    printf("%c\n", caractere);
    printf("%d\n", menor_valor);
  }else{
    printf("%s%c\n", letra,caractere);
    printf("%d\n", menor_valor);
  }
}
*/










/*
#include <stdio.h>
#include <string.h>

int main(){

  int soma = 0, resul = 0;
  char letra[22];
  scanf("%s", letra);
  int tam = strlen(letra);

  for(int i = 0; i < tam; i++){

    soma += letra[i];
  }

  //printf("%d\n", soma%50);

  int menor_valor = 50;
  char caractere;

  for(char j = 'a'; j < 'z'; j++){
    if((soma + j)%50 < menor_valor){
      menor_valor = (soma + j)%50;
      caractere = j;
    }
  }
  if(*letra == caractere){
    printf("%c\n", caractere);
    printf("%d\n", menor_valor);
  }else{
    if(menor_valor == 0){
      printf("%s%c\n", letra,caractere);
      //printf("%d\n", menor_valor);
    }else{
      printf("sem sorte\n");
    }
  }
}
*/