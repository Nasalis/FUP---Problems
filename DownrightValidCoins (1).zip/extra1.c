/*
#include <stdio.h>

int main(){

  int tam;
  scanf("%d", &tam);

  int numbers[tam];

  for(int i = 0; i < tam; i++){
      scanf("%d", &numbers[i]);

      for(int j = 0; j < i; j++){
          if(numbers[j] == numbers[i]){
              printf("Number %d written already\n", numbers[i]);
              break;
          }else{
            int soma = 0;
            soma += numbers[i];
            printf("A soma dos valores é: %d\n", soma);
          }
      }
  }
}
*/