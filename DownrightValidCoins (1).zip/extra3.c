/*

#include <stdio.h>

int main(){

  int size;
  scanf("%d", &size);

  int numbers[size], newArray[size], repeatArray[size];

  int indice = 0;

  for(int i = 0; i < size; i++){
    scanf("%d", &numbers[i]);

      int similar = 0;
      for(int j = 0; j < size; j++){
        if(newArray[j] == numbers[i]){
          repeatArray[j]++;
          similar = 1;
          break;
        }
      }

      if(!similar){
        newArray[indice] = numbers[i];
        repeatArray[indice] = 1;
        indice++; 
      }
  }
  
  printf("[");
  for(int i = 0; i < indice; i++){
    printf(" %d", newArray[i]);
  }
  printf("]\n");

  printf("[");
  for(int i = 0; i < indice; i++){
    printf(" %d", repeatArray[i]);
  }
  printf("]\n");
}
*/