/*

#include <stdio.h>

int main(){

  int tam;
  scanf("%d", &tam);

  int vetor[tam];
  int vetor2[tam];
  int vetor3[2*tam];

  for(int i = 0; i < tam; i++){
    scanf("%d", &vetor[i]);
  }

  for(int i = 0; i < tam; i++){
    scanf("%d", &vetor2[i]);
  }

  int i = 0, j = 0, k = 0;

  while(k < 2*tam){
    if(k%2 == 0){
      vetor3[k] = vetor[i];
      i++;
      k++;
    }else{
      vetor3[k] = vetor2[j];
      j++;
      k++;
    }
  }

  for(int k = 0; k < 2*tam; k++){
    printf("%d ", vetor3[k]);
  }
}
*/