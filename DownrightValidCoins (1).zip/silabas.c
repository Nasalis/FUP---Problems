/*
#include <stdio.h>
#include <string.h>


int ehVogal(char string){

  if( string >= 'A' && string <= 'Z'){
    string += ('a' - 'A');
  }
  if((string == 'a') || (string == 'e') || (string == 'i') || (string == 'o') || (string == 'u')){
    return 1;
  }
  if(string >= 'a' && string <= 'z'){
    return 2;
  }
  return 0;
}

int main(){

  char frase[50];
  scanf("%[^\n]s", frase);

  for(int i = 0; i != strlen(frase); i++){
    if((ehVogal(frase[i]) == 1) || (ehVogal(frase[i]) == 2)){
      if(frase[i] != '\n')
        printf("%c-", frase[i]);
    }
  }
}
*/








/*
#include <stdio.h>
#include <string.h>


char ehVogal(char string){
  char texto = string;

  if( string >= 'A' && string <= 'Z'){
    string += ('a' - 'A');
  }
  if((string == 'a') || (string == 'e') || (string == 'i') || (string == 'o') || (string == 'u')){
    return string;
  }
  if(string >= 'a' && string <= 'z'){
    return '-';
    return string;
  }
  return texto;
}

int main(){

  char frase[50];
  scanf("%[^\n]s", frase);

  for(int i = 0; i != strlen(frase); i++){
    //if((ehVogal(frase[i]) == 1) || (ehVogal(frase[i]) == 2)){
      if(frase[i] != '\n')
        printf("%c", ehVogal(frase[i]));
    }
  //}
}

*/