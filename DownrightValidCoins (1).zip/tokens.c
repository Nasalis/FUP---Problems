/*
#include <stdio.h>
#include <string.h>

int main(){

  char frase[102];
  scanf("%[^\n]s", frase);

  for(int i = 0; i < strlen(frase); i++){
    if(frase[i] == 35 || frase[i] == 59){
        printf("\n");
    }else{
        printf("%c", frase[i]);
    }
  }
}
*/