/*

#include <stdio.h>

int main(){

  int tam, number, pos = 0;
  scanf("%d %d", &tam, &number);

  int vetor[tam];

  for(int i = 0; i < tam; i++){
    scanf("%d", &vetor[i]);
  }
    for(int j = 0; j < tam; j++){
      if(vetor[j] != number){
         vetor[pos] = vetor[j];
         pos++;
    }
  }

  if(pos == tam){
      printf("%d nao estah presente no vetor\n", number);
  }else{
      for(int i = 0; i < pos; i++){
          printf("%d ", vetor[i]);
      }
  }
}
*/