// #include <stdio.h>

// int main(){

//   int rows, columns;
//   scanf("%d %d", &rows, &columns);

//   char campo[rows][columns];

//   for(int i = 0; i < rows; i++){
//     for(int j = 0; j < columns; j++){
//       scanf(" %c", &campo[i][j]);
//     }
//   }

//   int soma = 0, ocorrencia = 0;

//   for(int i = 0; i < rows; i++){
//     for(int j = 0; j < columns; j++){
//       if(campo[i][j] == '-'){
//           if((campo[i+1][j] == '*') || (campo[i-1][j] == '*') || (campo[i][j+1] == '*') || (campo[i][j-1] == '*')){
//             ocorrencia = 8;
//             soma = 0;
//             ocorrencia--;
//             soma += (8 - ocorrencia);
//             printf("%d", soma);
//           }else{
//             campo[i][j] = '-';
//             printf("%c", campo[i][j]);
//           }
//       };
//         printf("*");
//       }
//     }
//   }

//|| campo[i-1][j] == '*' ||  campo[i][j+1] == '*' || campo[i][j-1] == '*'
//|| campo[i-1][j+1] == '*' || campo[i+1][j+1] == '*' || campo[i+1][j+1] == '*'