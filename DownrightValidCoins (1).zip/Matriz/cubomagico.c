// #include <stdio.h>

// int matriz[3][3];

// int main(){

//   for(int i = 0; i < 3; i++){
//     for(int j = 0; j < 3; j++){
//       scanf("%d", &matriz[i][j]);
//     }
//   }

//   int somaL1 = 0, somaL2 = 0, somaL3 = 0, somaDP = 0, somaDS = 0;

//   for(int i = 0; i < 3; i++){
//     for(int j = 0; j < 3; j++){
      
//       if(i == 0){
//         somaL1 += matriz[0][j];
//       }else if(i == 1){
//         somaL2 += matriz[1][j];
//       }else{
//         somaL3 += matriz[2][j];
//       }
//     }
//   }

//   for(int i = 0; i < 3; i++){
//     for(int j = 0; j < 3; j++){
//       if(i == j){
//         somaDP += matriz[i][j];
//       }
//     }
//   }

//   for(int i = 0; i < 3; i++){
//     for(int j = 0; j < 3; j++){
//       if(i + j == 3 - 1){
//         somaDS += matriz[i][j]; 
//       }
//     }
//   }

//   if(somaL1 == somaL2 && somaL2 == somaL3 && somaL3 == somaDP && somaDP == somaDS){
//     printf("sim\n");
//   }else{
//     printf("nao\n");
//   }

//   /*
//   Veririfcar as saídas

//   printf("Soma Linha 1: %d\n", somaL1);
//   printf("Soma Linha 2: %d\n", somaL2);
//   printf("Soma Linha 3: %d\n", somaL3);
//   printf("DP: %d\n", somaDP);
//   printf("DS: %d\n", somaDS);
//   */
// }






// int somas_linha(int matriz[3][3], int tam){

//   int somaL1 = 0, somaL2 = 0, somaL3 = 0;
  

// }


// #include <stdio.h>

// int matriz[3][3];

// int main(){

//   for(int i = 0; i < 3; i++){
//     for(int j = 0; j < 3; j++){
//       scanf("%d", &matriz[i][j]);
//     }
//   }

//   int somaL1 = 0, somaL2 = 0, somaL3 = 0, somaDP = 0, somaDS = 0;

//   for(int i = 0; i < 3; i++){
//     for(int j = 0; j < 3; j++){
      
//       if(i == 0){
//         somaL1 += matriz[0][j];
//       }else if(i == 1){
//         somaL2 += matriz[1][j];
//       }else{
//         somaL3 += matriz[2][j];
//       }
//     }
//   }

//   for(int i = 0; i < 3; i++){
//     for(int j = 0; j < 3; j++){
//       if(i == j){
//         somaDP += matriz[i][j];
//       }
//     }
//   }

//   for(int i = 0; i < 3; i++){
//     for(int j = 0; j < 3; j++){
//       if(i + j == 3 - 1){
//         somaDS += matriz[i][j]; 
//       }
//     }
//   }

//   if(somaL1 == somaL2 && somaL2 == somaL3 && somaL3 == somaDP && somaDP == somaDS){
//     printf("sim\n");
//   }else{
//     printf("nao\n");
//   }

//   /*
//   Veririfcar as saídas

//   printf("Soma Linha 1: %d\n", somaL1);
//   printf("Soma Linha 2: %d\n", somaL2);
//   printf("Soma Linha 3: %d\n", somaL3);
//   printf("DP: %d\n", somaDP);
//   printf("DS: %d\n", somaDS);
//   */
// }