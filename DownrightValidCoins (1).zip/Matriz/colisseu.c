// #include <stdio.h>

// int main(){

//   int tam;
//   int leao;

//   leao = -1;

//   scanf("%d", &tam);
//   char arena[tam][tam];

//   for(int i = 0; i < tam; i++){
//     for(int j = 0; j < tam; j++){
//       scanf(" %c", &arena[i][j]);
//         if(arena[i][j] == 'L'){
//           leao = i;
//         }
//     }
//   }

//   int gladiador = 0;
//   int condenados = 0;


//   for(int i = 0; i < tam; i++){

//     if(i == leao) continue;

//     for(int j = 0; j < tam; j++){
//       if(arena[i][j] == 'C'){

//         if(i+j == tam-1){
//           condenados += 2;
//         }else{
//           condenados++;
//         }
//       }
//       else if(arena[i][j] == 'G'){
//         gladiador += 2;
//       }
//     }
//   }

//   if(gladiador > condenados){
//     printf("Gladiadores %d\n", gladiador);
//   }
//   else if(condenados > gladiador){
//     printf("Condenados a morte %d\n", condenados);
//   }else{
//     printf("Ninguem\n");
//   }
// }









// int vencedor(int tam, int leao, char arena[3][3]){

//   int gladiador = 0;
//   int condenados = 0;


//     int i = 0;

//     while(i < tam){

//       if(i != leao){

//         for(int j = 0; j < tam; j++){

//           if(arena[i][j] == 'C'){

//             if(i+j == tam-1){
//               condenados += 2;
//             }else{
//               condenados++;
//             }
//           }
//           else if(arena[i][j] == 'G'){
//             gladiador += 2;
//           }
//         }
//       }
//       i++;
//     }

//   if(gladiador > condenados){
//     return 1;
//   }
//   else if(condenados > gladiador){
//     return 2;
//   }else{
//     return 3;
//   }
//   return 0;
// }

// #include <stdio.h>

// int main(){

//   int tam;
//   int leao;

//   leao = -1;

//   scanf("%d", &tam);
//   char arena[tam][tam];

//   int res;

//   for(int i = 0; i < tam; i++){
//     for(int j = 0; j < tam; j++){
//       scanf(" %c", &arena[i][j]);

//         if(arena[i][j] == 'L'){
//           leao = i;
//         }
        
//         res = vencedor(tam, leao, arena);
//     }
//   }

//   if(res == 1){
//     printf("Gladiadores\n");
//   }
//   else if(res == 2){
//     printf("Condenados a morte\n");
//   }else if(res == 3){
//     printf("Ninguem\n");
//   }
// }










// #include <stdio.h>

// int main(){

//   int tam;
//   int leao;

//   leao = -1;

//   scanf("%d", &tam);
//   char arena[tam][tam];

//   for(int i = 0; i < tam; i++){
//     for(int j = 0; j < tam; j++){
//       scanf(" %c", &arena[i][j]);
//         if(arena[i][j] == 'L'){
//           leao = i;
//         }
//     }
//   }

//   int gladiador = 0;
//   int condenados = 0;

//   int i = 0;
//   while(i < tam){

//     if(i != leao){

//       for(int j = 0; j < tam; j++){
//         if(arena[i][j] == 'C'){

//           if(i+j == tam-1){
//             condenados += 2;
//           }else{
//             condenados++;
//           }
//         }
//         else if(arena[i][j] == 'G'){
//           gladiador += 2;
//         }
//       }
//     }
//     i++;
//   }

//   if(gladiador > condenados){
//     printf("Gladiadores %d\n", gladiador);
//   }
//   else if(condenados > gladiador){
//     printf("Condenados a morte %d\n", condenados);
//   }else{
//     printf("Ninguem\n");
//   }
// }