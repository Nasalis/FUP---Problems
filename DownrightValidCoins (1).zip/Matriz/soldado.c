// #include <stdio.h>
// #define MAX 3

// int main(){

//   int fila[MAX][MAX];

//   for(int i = 0; i < MAX; i++){
//     for(int j = 0; j < MAX; j++){
//         scanf("%d", &fila[i][j]);
//     }
//   }

//   int soma = 0;

//   for(int i = 1; i < MAX; i++){
//     for(int j = 0; j < MAX; j++){
//       if(fila[i-1][j] > fila[i][j]){
//         soma++;
//         //printf("Fila: %d - %d\n", fila[i][j], fila[i+1][j]); 
//         // Codigo para verificar comparações
//       }
//     }
//   }
//   printf("%d\n", soma);
// }