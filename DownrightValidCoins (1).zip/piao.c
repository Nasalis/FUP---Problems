/*
#include <stdio.h>

int main(){

  int circun, qtd, pos = 0, los = 0;
  int dist = 0;

  scanf("%d %d", &circun, &qtd);

  int jog[qtd];

  for(int i = 0; i < qtd; i++){
      scanf("%d", &jog[i]); 
      
      dist += jog[i];

      if((circun - jog[i]) > (circun - jog[i+1])){
          los = i;
      }
      if(jog[i] < circun){
          pos = i;
      }
  }
  printf("%d\n", pos);
  printf("%d\n", los);
}
*/