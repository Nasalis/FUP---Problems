
/*
#include <stdio.h>
#include <string.h>

char trocaVogal(const char *s){
  char i;
  char vogais[12] = "AaEeIiOoUu";

  for(i = 0; i < 10; i++){
      if(s[i] == vogais[i]){
            return  1;
      }
  }
  return 0;
}

int main(){

  char frase[52];
  scanf("%[^\n]s", frase);

  for(int i = 0; i < strlen(frase); i++){
    if(trocaVogal(frase) == 1){
      frase[i] = 'c';
    }
    printf("%s ", frase);
  }
}
*/


/*
#include <stdio.h>
#include <string.h>

char trocaLetras(char s){
  char novoTexto = s;

  if(s >= 'A' && s <= 'Z'){
    s += ('a' - 'A');
  }
  if((s == 'a') || (s == 'e') || (s == 'i') || (s == 'o') || (s == 'u')){
    return 'v';
  }
  if(s >= 'a' && s <= 'z'){
    return 'c';
  }
  return novoTexto;
}

int main(){

  char texto[52];
  scanf("%[^\n]s", texto);

  for(int i = 0; i != strlen(texto); i++){
    if(texto[i] != '\n'){
      printf("%c", trocaLetras(texto[i]));
    }
  }
  printf("\n");
}
*/











// QUESTÃO DO JOKENPO - ALTERNATIVA
// #include <stdio.h>
// #include <string.h>

// int main(){
 
//   char elementos[50];
//   char jog1[50];
//   char jog2[50];

//   int n1, n2;

//   scanf("%s", jog1);
//   scanf("%s", jog2);

//   if(strcmp(jog1, "rock")     == 0) n1 = 0;
//   if(strcmp(jog1, "fire")     == 0) n1 = 1;
//   if(strcmp(jog1, "scissors") == 0) n1 = 2;
//   if(strcmp(jog1, "human")    == 0) n1 = 3;
//   if(strcmp(jog1, "sponge")   == 0) n1 = 4;
//   if(strcmp(jog1, "paper")    == 0) n1 = 5;
//   if(strcmp(jog1, "air")      == 0) n1 = 6;
//   if(strcmp(jog1, "water")    == 0) n1 = 7;
//   if(strcmp(jog1, "gun")      == 0) n1 = 8;

//   if(strcmp(jog2, "rock")     == 0) n2 = 0;
//   if(strcmp(jog2, "fire")     == 0) n2 = 1;
//   if(strcmp(jog2, "scissors") == 0) n2 = 2;
//   if(strcmp(jog2, "human")    == 0) n2 = 3;
//   if(strcmp(jog2, "sponge")   == 0) n2 = 4;
//   if(strcmp(jog2, "paper")    == 0) n2 = 5;
//   if(strcmp(jog2, "air")      == 0) n2 = 6;
//   if(strcmp(jog2, "water")    == 0) n2 = 7;
//   if(strcmp(jog2, "gun")      == 0) n2 = 8;


//   if(n1 == n2){
//     printf("empate\n");
//   }else{
//     if((n2 == (n1 + 1)%9) || (n2 == (n1 + 2)%9) || (n2 == (n1 + 3)%9) || (n2 == (n1 + 4)%9)){
//       printf("jog1\n");
//     }else{
//       printf("jog2\n");
//     }
//   }
// }

























// QUESTÃO DO JOKENPO NA FORÇA BRUTA 

/*
#include <stdio.h>
#include <string.h>

int main(){

  char jog1[50];
  char jog2[50];

  scanf("%s", jog1);
  scanf("%s", jog2);

  if(strcmp(jog1, jog2) == 0){
    printf("empate\n");
  }
  else if((strcmp(jog1, "fire") == 0) && (strcmp(jog2, "human") == 0)){
    printf("jog1\n");
  }
  else if((strcmp(jog1, "fire") == 0) && (strcmp(jog2, "scissors") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "fire") == 0) && (strcmp(jog2, "sponge") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "fire") == 0) && (strcmp(jog2, "paper") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "scissors") == 0) && (strcmp(jog2, "human") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "scissors") == 0) && (strcmp(jog2, "sponge") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "scissors") == 0) && (strcmp(jog2, "paper") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "scissors") == 0) && (strcmp(jog2, "air") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "human") == 0) && (strcmp(jog2, "sponge") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "human") == 0) && (strcmp(jog2, "paper") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "human") == 0) && (strcmp(jog2, "air") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "human") == 0) && (strcmp(jog2, "water") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "sponge") == 0) && (strcmp(jog2, "paper") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "sponge") == 0) && (strcmp(jog2, "air") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "sponge") == 0) && (strcmp(jog2, "water") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "sponge") == 0) && (strcmp(jog2, "gun") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "paper") == 0) && (strcmp(jog2, "air") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "paper") == 0) && (strcmp(jog2, "water") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "paper") == 0) && (strcmp(jog2, "gun") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "paper") == 0) && (strcmp(jog2, "rock") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "air") == 0) && (strcmp(jog2, "water") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "air") == 0) && (strcmp(jog2, "gun") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "air") == 0) && (strcmp(jog2, "rock") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "air") == 0) && (strcmp(jog2, "fire") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "water") == 0) && (strcmp(jog2, "gun") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "water") == 0) && (strcmp(jog2, "rock") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "water") == 0) && (strcmp(jog2, "fire") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "water") == 0) && (strcmp(jog2, "scissors") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "gun") == 0) && (strcmp(jog2, "rock") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "gun") == 0) && (strcmp(jog2, "fire") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "gun") == 0) && (strcmp(jog2, "scissors") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "gun") == 0) && (strcmp(jog2, "human") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "rock") == 0) && (strcmp(jog2, "fire") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "rock") == 0) && (strcmp(jog2, "scissors") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "rock") == 0) && (strcmp(jog2, "human") == 0)){
    printf("jog1\n");
  }else if((strcmp(jog1, "rock") == 0) && (strcmp(jog2, "sponge") == 0)){
    printf("jog1\n");
  }else{
    printf("jog2\n");
  }
}
*/