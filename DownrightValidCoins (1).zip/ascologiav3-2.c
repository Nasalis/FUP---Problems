/*
#include <stdio.h>
#include <string.h>

int main(){

  int soma = 0, resul = 0;
  char letra;

  while(scanf(" %c", &letra) != '\n'){
      soma += letra;
      scanf(" %c", &letra);
  }
  printf("%d\n", soma%50);

  int menor_valor = 50;
  char caractere;

  for(char j = 'a'; j < 'z'; j++){
    if((soma + j)%50 < menor_valor){
      menor_valor = (soma + j)%50;
      caractere = j;
    }
  }
  if(*letra == caractere){
    printf("%c\n", caractere);
    printf("%d\n", menor_valor);
  }else{
    printf("%s%c\n", letra,caractere);
    printf("%d\n", menor_valor);
  }
}
*/