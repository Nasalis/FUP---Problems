
/*
#include <stdio.h>
#include <string.h>

int main(){

  char frase[104];
  scanf("%[^\n]s", frase);

  int ind = 0;
  int tam = strlen(frase);

  for(int i = 0; i <= tam; i++){
    printf("%c", frase[i]);
      if(frase[i] == " "){
        for(int j = ind; j < i; j++){
          printf("%c", frase[j]);
        }
        printf(" ");
        ind = (i++);
      }
      if(frase[i] == '\0'){
        for(int l = ind; l < i; l++){
          printf("%c", frase[l]);
        }
      }
  }
}
*/








/*
#include<stdio.h>
#include<string.h>
int main(){
    char str[100];
    scanf("%[^\n]s", str);
    int i = 0, k = 0, l = 0;
    int ini = 0;
    for(i = 0; i <= strlen(str); i++){
        printf("%c", str[i]);
        if(str[i] == ' '){
            for(k=ini;k<i;k++){
                printf("%c", str[k]);
            }
            printf(" ");
            ini = (i+1);
        }
        if(str[i] != '\0'){
            for(l=ini;l<i;l++){
                printf("%c", str[l]);
            }
        }
    }
}
*/







/*
#include <stdio.h>
#include <string.h>

int main() {
    
    char palavra[102];
    
    scanf("%s", palavra);
    printf("%s %s", palavra,palavra);
    
    while(scanf("%s", palavra) > 0){
        printf(" %s %s", palavra,palavra);
    }
    
    printf("\n");
}
*/