/*
#include <stdio.h>

int main(){

  int qtd;
  scanf("%d", &qtd);

  int cartas[qtd], soma = 0, a = 0;

  for(int i = 0; i < qtd; i++){
      scanf("%d", &cartas[i]); 

      if(cartas[i] > 10){
          soma += 10;
      }else if(cartas[i] == 1){
          soma += 11;
          a += 1;
      }else{
          soma += cartas[i];
      }

      if(soma > 21){
          soma += -a*10;
      }
  }
    printf("%d\n", soma);
}
*/

/*
#include <stdio.h>

int main(){

  int qtd;
  scanf("%d", &qtd);

  int carta, as = 0, soma = 0, aux = 1;

  for(aux = 1; aux <= qtd; aux++){
      scanf("%d", &carta);

      if(carta == 1){
          as++;
          soma += 11;
      }
        else if(carta >= 10){
            soma += 10;
        }
          else{
              soma += carta;
          }
  }
  while(soma > 21 && as > 0){
          soma -= 10;
          as--;
  }
  printf("%d\n", soma);
}
*/