/*
#include <stdio.h>
#include <string.h>

int main(){

  char linha[102];
  scanf("%[^\n]s", linha);
  strcat(linha, " ");

  int n = strlen(linha);

  int numeroPalavras = 0;

  for(int i = 0; i < n; i++){
    if(linha[i] == ' ') numeroPalavras++;
  }

  int cont = 0;
  for(char c = 'a'; c <= 'z'; c++){
    
    int contP = 0;
    for(int i = 0; i < n; i++){
      if(linha[i] == c){
        contP++;

        while(linha[i] != ' ') i++;
      }
    }

    if(contP == numeroPalavras){
      cont++;
    }
  }

  printf("%d\n", cont);
}
*/