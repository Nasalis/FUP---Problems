/*
#include <stdio.h>

long long numero_graos(int ano){
  
  int cont = 0;
  int valor;

  for(int i = 1; i <= ano; i++){
    printf("Valor: %d\n", i);
    cont = ano + (ano-1);
    //cont = ano + (ano-1);
  }
  return cont;
}


int main(){

  int graos;
  scanf("%d", &graos);

  int resul = numero_graos(graos);

  printf("%d\n", resul);
}
*/