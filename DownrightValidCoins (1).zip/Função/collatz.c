/*
#include <stdio.h>
#include <assert.h>





int collatz(int n) {

  int cont = 0, soma = 0;

  while(soma != 1){
    int div, calc;

    if(n%2 == 0){
      div = n/2;
    }else{
      calc = (3*n) + 1;
    }
    cont++;
    soma += (div + calc);
  }
  return cont;
}








int collatz(int n){

    printf("%d ", n);

    int cont = 0, soma = 0;

    cont += n;

      if(n > 1){
          if(n%2 == 0){
            collatz(n/2);
          }else{
            collatz((3*n)+1);
          }
      }
    
    return cont;
}


int main(){
    //assert( collatz(12) == 9 );

    int number;
    scanf("%d", &number);

    //collatz(number);

    printf("%d\n", collatz(number));
}
*/