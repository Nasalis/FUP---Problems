/*
#include <stdio.h>

char zeroUm(int a, int b, int c){
  if(a != b && a != c){
    return 'A';
  }
  else if(b != a && b != c){
    return 'B';
  }
  else if(c != a && c != b){
    return 'C';
  }else{
    return '*';
  }
}

int main(){

  int alice, beto, clara;
  
  scanf("%d %d %d", &alice, &beto, &clara);

  printf("%c\n", zeroUm(alice, beto, clara));

}
*/