/*
#include <stdio.h>

int soma_multiplos(int v[], int n, int limite){

  int cont = 0;

  for(int j = 0; j < limite; j++){
    for(int i = v[0]; i < v[n-1]; i++){
      if(j%v[i] == 0 || j%v[i+1] == 0) {
        cont += j;
      }
    }
  }
  return cont;
}

int main() { 
  int v[] = {3,5};
  printf("%d\n", soma_multiplos(v, 2, 20)); //78
  return 0;
}
*/





/*
int main(){

  int v[] = {3,5};

  int cont = 0;

  for(int j = 0; j < 20; j++){
      if((j%3 == 0) || (j%5 == 0)) {
       cont += j;
      }
  }

  printf("%d\n", cont); //78

}
*/