/*
#include <stdio.h>
#include <ctype.h>
#include <string.h>

void minusculo(char* str) {

  for(int i = 0; i < strlen(str); i++){
    printf("%c", tolower(str[i]));
  }
  printf("\n");
}

int main(){

  char texto[100];
  scanf("%[^\n]s", texto);

  minusculo(texto);
}
*/