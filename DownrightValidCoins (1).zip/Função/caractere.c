/*
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int contaChar (char c, char* str){

  int cont = 0;
  for(int i = 0; i < strlen(str); i++){
      if(str[i] == c){
        cont++;
      }
  }

  return cont;
  
}


int main(){

  char letra;
  char texto[20];

  scanf("%c ", &letra);
  scanf("%[^\n]s", texto);


  int cont = 0;
  for(int i = 0; i < strlen(texto); i++){
      if(texto[i] == letra || texto[i] == toupper(letra)){
        cont++;
      }
  }

  printf("%d\n", contaChar(letra, texto));
}
*/
