/*
#include <stdio.h>
#include <math.h>

int numPow(int a, int b){
  int resul;

  resul = pow(a, b);

  return resul;
}

int main(){

  int valor, expoente;
  scanf("%d %d", &valor, &expoente);

  int res = numPow(valor, expoente);

  printf("%d\n", res);
}
*/