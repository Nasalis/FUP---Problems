
// #include <stdio.h>
// #include <string.h>
// #include <ctype.h>

// int main(){

//   int qtd, tam;
//  // scanf("%d", &qtd);

//   char texto[102];

//   scanf("%[^\n]s", texto);
//   tam = strlen(texto);
  
//   for(int j = 0; j <= tam; j++){
    
//     if(texto[j] == toupper(texto[j])){
//       if(j%2 != 0){
//         if(texto[j] >= 65 && texto[j] <= 90){
//           texto[j] += 32;
//         }
//       }else{
//         if(texto[j] >= 97 && texto[j] <= 122){
//           texto[j] -= 32;
//         }
//       }
//     }else if(texto[j] == tolower(texto[j])){
//       if(j%2 != 0){
//         if(texto[j] >= 97 && texto[j] <= 122){
//           texto[j] -= 32;
//         }
//       }else{
//         if(texto[j] >= 65 && texto[j] <= 90){
//           texto[j] += 32;
//         }
//       }     
//     }
//   }
//   printf("%s", texto);
// }











/*
#include <stdio.h>
#include <string.h>

int main(){
  int tam;
  char texto[102];

  scanf("%s", texto);
  tam = strlen(texto);
  
  for(int j = 0; j < tam; j++){
      if(texto[j] >= 65 && texto[j] <= 90){
        texto[j] += 32;
        printf("%c\n", texto[j]);
        break;
      }else if(texto[j] >= 97 && texto[j] <= 122){
        texto[j] -= 32;
        printf("%c\n", texto[j]);
        break;
      }else if(texto[j] >= 48 && texto[j] <= 57){
        printf("%c\n", texto[j]);
        break;
      }else{
        printf("%c\n", texto[j]);
        break;
      }
    }
}
*/





/*
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(){

  int qtd;
  char frase[102];

  //scanf("%d ", &qtd);

  scanf("%[^\n]s", frase);

  // for(int i = 0; i < qtd; i++){
  // }

  int tam = strlen(frase);

  for(int i = 0; i < tam; i++){
    if(frase[0] == toupper(frase[0])){
      printf("%c%c", toupper(frase[i]), tolower(frase[i]));
    }
  }
}
*/