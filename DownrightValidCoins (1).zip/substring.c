/*
#include <stdio.h>
#include <string.h>

int main(){

  char texto[102];
  int indice, letras;

  scanf("%[^\n]s", texto);
  scanf("%d %d", &indice, &letras);

  int tam = strlen(texto);

  if(tam < letras){
      letras = tam;
  }

  for(int i = indice; i < letras; i++){
    printf("%c", texto[i]);
    if(texto[i] == '\0')
      break;
  }
  printf("\n");
}
*/




/*
#include <stdio.h>
#include <string.h>

int main(){

  char texto[102];
  int indice, letras;

  scanf("%[^\n]s", texto);
  scanf("%d %d", &indice, &letras);

  int tam = strlen(texto);

  if(tam < letras){
      letras = tam;
  }

  for(int j = indice; j < letras; j++){
    if(j == tam){
        break;
    }
    printf("%c", texto[j]);
  }
  printf("\n");
}
*/