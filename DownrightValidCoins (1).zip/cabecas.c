/*

#include <stdio.h>

int main(){

  int qtd, jog, membros, pos;
  scanf("%d %d", &qtd, &jog);

  int valores[qtd];

  for(int i = 0; i < qtd; i++){
    valores[i] = i+1;
  }

  pos = jog-1;

  for(membros = qtd;membros > 1; membros--){

    do{
      pos = (pos + 1)%qtd;
    }while(valores[pos] == -1);

    valores[pos] = -1;

    do{
      pos = (pos + 1)%qtd;
    }while(valores[pos] == -1);
  }
  printf("%d\n", valores[pos]);
}

*/


/*

#include <stdio.h>

int sobrevivente(int qtd, int jog, int membros){

int valores[qtd], pos;

  for(int i = 0; i < qtd; i++){
    valores[i] = i+1;
  }

  pos = jog-1;

  for(membros = qtd;membros > 1; membros--){

    do{
      pos = (pos + 1)%qtd;
    }while(valores[pos] == -1);

    valores[pos] = -1;

    do{
      pos = (pos + 1)%qtd;
    }while(valores[pos] == -1);
  }

  return valores[pos];
}

int main(){

  int qtd, jog, membros;
  scanf("%d %d", &qtd, &jog);

  int valores[qtd], sobrevive;
  
  sobrevive = sobrevivente(qtd, jog, membros);

  printf("%d\n", sobrevive);
}

*/